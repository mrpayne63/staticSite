console.log('just a static resource');
