"use strict";

exports.timezones = require('./timezones');
