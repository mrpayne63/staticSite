"use strict";

exports.movies = require('./movies');
exports.errors = require('./errors');
