"use strict";

module.exports = {
  users: require('./users'),
  notes: require('./notes')
};
